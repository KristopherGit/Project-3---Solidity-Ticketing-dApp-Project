def home():
    welcome_message = "Welcome to TFS APIs 🙏 <br/> GitHub Repository Link : https://github.com/wweverma1/tfs-backend <br/> Developed with ❤️ by Aditya Verma"
    return welcome_message, 200
